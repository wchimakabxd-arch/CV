package edu.actividad;

import jakarta.persistence.EntityManager;
import jakarta.persistence.EntityManagerFactory;

public class NuevaPeliculaConRollback {
    public static void main(String[] args) {
        try (EntityManagerFactory emf = Util.factory()) {
            EntityManager em = emf.createEntityManager();
            try {
                em.getTransaction().begin();
                String titulo = Util.leer("Título de la nueva película: ");
                String director = Util.leer("Director: ");
                PeliculaEntity p = new PeliculaEntity(titulo, director);
                em.persist(p);
                em.flush(); // Envía el INSERT a la BD, pero aún no confirma la transacción.
                System.out.println("Después de flush(), ID asignado: " + p.getId());
                Util.pausa("Ahora, en OTRA terminal, ejecuta ListarPeliculas para comprobar si se ve.");
                String error = Util.leer("¿Provocamos error (s/n)?: ");
                if (error.equalsIgnoreCase("s")) throw new RuntimeException("Error provocado para probar rollback");
                em.getTransaction().commit();
                System.out.println("Transacción confirmada (COMMIT). La película debe quedar guardada.");
            } catch (Exception ex) {
                if (em.getTransaction().isActive()) em.getTransaction().rollback();
                System.out.println("Ocurrió: " + ex.getMessage());
                System.out.println("Se ejecutó ROLLBACK. La película insertada en esta transacción no debe quedar guardada.");
            } finally { em.close(); }
        }
    }
}
