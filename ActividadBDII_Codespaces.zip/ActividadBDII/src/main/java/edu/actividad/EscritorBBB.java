package edu.actividad;

import jakarta.persistence.EntityManager;
import jakarta.persistence.EntityManagerFactory;

public class EscritorBBB {
    public static void main(String[] args) {
        try (EntityManagerFactory emf = Util.factory()) {
            EntityManager em = emf.createEntityManager();
            try {
                em.getTransaction().begin();
                PeliculaEntity p = em.find(PeliculaEntity.class, 10L);
                if (p == null) throw new IllegalStateException("No existe ID 10. Ejecuta PrepararDatos primero.");
                String antes = p.getTitulo();
                p.setTitulo("Título cambiado por BBB");
                System.out.println("BBB: título leído = " + antes);
                System.out.println("BBB: cambio preparado.");
                Util.pausa("Pulsa ENTER para intentar confirmar el cambio de BBB.");
                em.getTransaction().commit();
                System.out.println("BBB: COMMIT realizado.");
            } catch (Exception ex) {
                if (em.getTransaction().isActive()) em.getTransaction().rollback();
                System.out.println("BBB: transacción cancelada: " + ex.getClass().getSimpleName() + " - " + ex.getMessage());
            } finally { em.close(); }
        }
    }
}
