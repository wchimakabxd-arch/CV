package edu.actividad;

import jakarta.persistence.EntityManager;
import jakarta.persistence.EntityManagerFactory;
import java.util.List;

public class ListarPeliculas {
    public static void main(String[] args) {
        try (EntityManagerFactory emf = Util.factory()) {
            EntityManager em = emf.createEntityManager();
            try {
                List<PeliculaEntity> lista = em.createQuery(
                    "select p from PeliculaEntity p order by p.id", PeliculaEntity.class
                ).getResultList();
                System.out.println("\n--- PELÍCULAS VISIBLES EN ESTA CONSULTA ---");
                lista.forEach(System.out::println);
                System.out.println("Total visibles: " + lista.size());
            } finally { em.close(); }
        }
    }
}
