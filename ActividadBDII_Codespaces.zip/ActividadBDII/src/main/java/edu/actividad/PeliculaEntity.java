package edu.actividad;

import jakarta.persistence.*;

@Entity
@Table(name = "peliculas")
public class PeliculaEntity {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(nullable = false, length = 150)
    private String titulo;

    @Column(length = 100)
    private String director;

    // Actividad 3: la anotación @Version activa el control optimista de concurrencia.
    // Si el módulo pide hacer la prueba SIN versión, comenta estas dos líneas.
    @Version
    private Integer version;

    public PeliculaEntity() {}
    public PeliculaEntity(String titulo, String director) {
        this.titulo = titulo;
        this.director = director;
    }
    public Long getId() { return id; }
    public String getTitulo() { return titulo; }
    public void setTitulo(String titulo) { this.titulo = titulo; }
    public String getDirector() { return director; }
    public void setDirector(String director) { this.director = director; }
    public Integer getVersion() { return version; }
    @Override public String toString() {
        return "ID=" + id + " | título=" + titulo + " | director=" + director + " | versión=" + version;
    }
}
