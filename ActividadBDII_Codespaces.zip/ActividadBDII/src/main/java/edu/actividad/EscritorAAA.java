package edu.actividad;

import jakarta.persistence.EntityManager;
import jakarta.persistence.EntityManagerFactory;

public class EscritorAAA {
    public static void main(String[] args) {
        escribir("AAA");
    }
    static void escribir(String sufijo) {
        try (EntityManagerFactory emf = Util.factory()) {
            EntityManager em = emf.createEntityManager();
            try {
                em.getTransaction().begin();
                PeliculaEntity p = em.find(PeliculaEntity.class, 10L);
                if (p == null) throw new IllegalStateException("No existe ID 10. Ejecuta PrepararDatos primero.");
                String antes = p.getTitulo();
                p.setTitulo("Título cambiado por " + sufijo);
                System.out.println(sufijo + ": título anterior = " + antes);
                System.out.println(sufijo + ": cambio preparado, aún sin commit.");
                Util.pausa("Deja esta aplicación esperando. Abre otra terminal y ejecuta EscritorBBB.");
                em.getTransaction().commit();
                System.out.println(sufijo + ": COMMIT realizado.");
            } catch (Exception ex) {
                if (em.getTransaction().isActive()) em.getTransaction().rollback();
                System.out.println(sufijo + ": transacción cancelada: " + ex.getClass().getSimpleName() + " - " + ex.getMessage());
            } finally { em.close(); }
        }
    }
}
