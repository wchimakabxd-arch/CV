package edu.actividad;

import jakarta.persistence.EntityManager;
import jakarta.persistence.EntityManagerFactory;
import jakarta.persistence.Persistence;
import java.util.HashMap;
import java.util.Map;
import java.util.Scanner;

public final class Util {
    private static final Scanner IN = new Scanner(System.in);
    private Util() {}
    public static EntityManagerFactory factory() {
        Map<String,Object> p = new HashMap<>();
        String iso = System.getProperty("isolation");
        if (iso != null && !iso.isBlank()) p.put("hibernate.connection.isolation", Integer.parseInt(iso));
        return Persistence.createEntityManagerFactory("filmoteca", p);
    }
    public static String leer(String texto) {
        System.out.print(texto);
        return IN.nextLine().trim();
    }
    public static void pausa(String texto) {
        System.out.println(texto);
        leer("Pulsa ENTER para continuar...");
    }
}
