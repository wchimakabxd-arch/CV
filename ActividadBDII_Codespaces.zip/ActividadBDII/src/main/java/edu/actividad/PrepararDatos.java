package edu.actividad;

import jakarta.persistence.EntityManager;
import jakarta.persistence.EntityManagerFactory;

public class PrepararDatos {
    public static void main(String[] args) {
        try (EntityManagerFactory emf = Util.factory()) {
            EntityManager em = emf.createEntityManager();
            try {
                em.getTransaction().begin();
                if (em.createQuery("select count(p) from PeliculaEntity p", Long.class).getSingleResult() == 0) {
                    for (int i = 1; i <= 10; i++) {
                        em.persist(new PeliculaEntity("Película " + i, "Director " + i));
                    }
                }
                em.getTransaction().commit();
                System.out.println("Datos listos. Comprueba que existe la película con ID 10.");
            } finally { em.close(); }
        }
    }
}
