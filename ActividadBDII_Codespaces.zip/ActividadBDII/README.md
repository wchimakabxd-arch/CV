# Actividades 1, 2 y 3 — Base de Datos II

Proyecto didáctico Java + JPA/Hibernate + H2 para probar transacciones, aislamiento y concurrencia.

## Requisitos
Java 17 o superior y Maven. La base de datos H2 se guarda en `./datos/filmoteca`.

## Abrirlo en Codespaces
Sube/descomprime esta carpeta en tu espacio de Codespaces. En la terminal, entra a la carpeta que contiene `pom.xml`.

## Primera ejecución
```bash
mvn -q compile exec:java -Dexec.mainClass=edu.actividad.PrepararDatos
```
Esto crea las tablas y 10 películas de ejemplo; debe existir una película con ID 10.

## Actividad 1 — COMMIT y ROLLBACK
Terminal 1:
```bash
mvn -q compile exec:java -Dexec.mainClass=edu.actividad.NuevaPeliculaConRollback
```
Escribe título y director. Cuando se detenga en la pausa, abre otra terminal (+ en el panel Terminal) y ejecuta:
```bash
mvn -q compile exec:java -Dexec.mainClass=edu.actividad.ListarPeliculas
```
Vuelve a la primera terminal y pulsa ENTER. Escribe `s` para provocar error/ROLLBACK, o `n` para confirmar/COMMIT. Vuelve a ejecutar ListarPeliculas.
- Antes del commit, otra transacción normalmente no ve la película nueva.
- Con `s`, la inserción se revierte. Con `n`, queda guardada.
- `flush()` envía el INSERT, pero no confirma la transacción. El identificador puede quedar consumido incluso si hay rollback.

## Actividad 2 — Aislamiento
Abre `src/main/resources/META-INF/persistence.xml`. Cambia:
```xml
<property name="hibernate.connection.isolation" value="2"/>
```
por `value="1"`, guarda y repite la Actividad 1. Después repite con `value="2"` para comparar.
En esta prueba, H2 puede tratar READ_UNCOMMITTED como READ_COMMITTED; por eso el resultado puede no cambiar. Indícalo en las conclusiones: el comportamiento depende del motor de base de datos, y no todos implementan todos los niveles de aislamiento de la misma forma.

## Actividad 3 — Concurrencia y @Version
Primero confirma que existe la película ID 10. En `persistence.xml`, prueba los valores 2, 1, 4 y 8, uno a la vez.
1. Terminal 1:
```bash
mvn -q compile exec:java -Dexec.mainClass=edu.actividad.EscritorAAA
```
Cuando AAA se detenga en la pausa, abre Terminal 2:
```bash
mvn -q compile exec:java -Dexec.mainClass=edu.actividad.EscritorBBB
```
2. AAA y BBB modifican la misma película. En BBB, pulsa ENTER para intentar confirmar; después pulsa ENTER en AAA para terminar. Observa si espera, confirma o falla y revisa el resultado con `ListarPeliculas`.
3. Para la prueba SIN control optimista, comenta temporalmente solo la anotación `@Version` en `PeliculaEntity.java` (deja el campo `private Integer version;` para que el proyecto siga compilando). Ejecuta de nuevo las pruebas.
4. Para la prueba CON control optimista, vuelve a activar la anotación `@Version`, recompila y repite. Hibernate usa la columna de versión para detectar actualizaciones conflictivas y una de las transacciones puede fallar con una excepción de concurrencia.

Importante: los bloqueos y resultados exactos dependen del motor y del orden de confirmación. No afirmes que todos los niveles producirán siempre el mismo resultado.

## Comandos útiles
Listar películas:
```bash
mvn -q compile exec:java -Dexec.mainClass=edu.actividad.ListarPeliculas
```
Reiniciar desde cero: detén las aplicaciones, borra la carpeta `datos/` y ejecuta PrepararDatos de nuevo. Esto elimina los datos de prueba.

## Limitación respecto al módulo
Este proyecto reproduce los conceptos de las actividades con una base H2 local y nombres de clases sencillos. Si el docente exige literalmente el proyecto `filmoteca` original, sus clases o un motor específico (MySQL/PostgreSQL), habrá que adaptar este código al material proporcionado por la asignatura.
